from KDSlib import Legato110, KdsUtil

# test connection
u = KdsUtil("port", 115200)
l = Legato110()

# test run commands
