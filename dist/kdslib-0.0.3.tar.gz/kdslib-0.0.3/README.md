## KDSlib

A python wrapper + automation features for the KDS Legato 110. 