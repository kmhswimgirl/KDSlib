from src.KDSautolib import Legato110, KdsUtil

# test connection
u = KdsUtil("port", 115200)
l = Legato110("port", 115200)

# test run commands
