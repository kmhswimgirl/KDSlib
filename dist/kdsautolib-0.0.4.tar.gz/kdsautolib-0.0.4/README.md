## KDSautolib

A python wrapper + automation features for various KDS devices. 

Features a class for each specific KDS device and a utilities class (KdsUtil) for lower level control.

### Supported Devices:
- Legato 110 (partial)